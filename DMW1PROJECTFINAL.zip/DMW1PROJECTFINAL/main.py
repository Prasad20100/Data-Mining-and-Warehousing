import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# --- Page Config ---
st.set_page_config(page_title="🎓 Personalized Learning System", layout="wide")

# --- Title Area ---
st.markdown("<h1 style='color:#4CAF50;'>🎓 Personalized Learning System for Students</h1>", unsafe_allow_html=True)
st.markdown("A data mining-powered tool that clusters students and suggests tailored learning strategies.")

# --- Sidebar ---
st.sidebar.image("student-center.png", width=80)
st.sidebar.title("🔍 Navigation")
uploaded_file = st.sidebar.file_uploader("📂 Upload Student CSV File", type=["csv"])

menu = st.sidebar.radio("📌 Choose Action", [
    "🔎 Raw Data Preview",
    "🧹 Outlier Removal",
    "⚙️ Preprocess Data",
    "📉 Elbow Method",
    "🌀 Clustering",
    "📈 Cluster Analysis"
])

# --- Functions ---

def load_data(file):
    df = pd.read_csv(file)
    df.drop(columns=[col for col in ['id', 'name'] if col in df.columns], inplace=True)
    return df

def remove_outliers(df):
    num_cols = df.select_dtypes(include=['float64', 'int64']).columns
    iso = IsolationForest(contamination=0.02, random_state=42)
    preds = iso.fit_predict(df[num_cols])
    return df[preds == 1]

def preprocess(df):
    categorical = df.select_dtypes(include=['object', 'bool']).columns.tolist()
    numerical = df.select_dtypes(include=['float64', 'int64']).columns.tolist()
    numerical = [col for col in numerical if col not in ['goal_oriented']]
    pipeline = ColumnTransformer([
        ('num', StandardScaler(), numerical),
        ('cat', OneHotEncoder(), categorical)
    ])
    transformed = pipeline.fit_transform(df)
    return transformed, pipeline

def find_optimal_k(X):
    distortions = []
    for k in range(2, 11):
        kmeans = KMeans(n_clusters=k, random_state=42)
        kmeans.fit(X)
        distortions.append(kmeans.inertia_)
    fig, ax = plt.subplots()
    ax.plot(range(2, 11), distortions, marker='o', color='green')
    ax.set_xlabel('k')
    ax.set_ylabel('Inertia')
    ax.set_title('Elbow Method - Optimal k')
    st.pyplot(fig)

def perform_clustering(X, k=4):
    model = KMeans(n_clusters=k, random_state=42)
    labels = model.fit_predict(X)
    return labels, model

def assign_cluster(df, labels):
    df_clustered = df.copy()
    df_clustered['cluster'] = labels
    return df_clustered

def analyze_clusters(df_clustered):
    st.subheader("📌 Cluster-wise Statistics")
    numeric_cols = df_clustered.select_dtypes(include=np.number).columns
    summary = df_clustered.groupby('cluster')[numeric_cols].mean()
    st.dataframe(summary.style.highlight_max(axis=0, color='lightgreen'))

    st.subheader("🎯 Personalized Cluster Recommendations")
    for cluster_id in df_clustered['cluster'].unique():
        with st.expander(f"🔹 Cluster {cluster_id}"):
            cluster = df_clustered[df_clustered['cluster'] == cluster_id]
            common_style = cluster['learning_style'].mode()[0] if not cluster['learning_style'].mode().empty else "N/A"
            common_material = cluster['study_material_preference'].mode()[0] if not cluster['study_material_preference'].mode().empty else "N/A"
            avg_engagement = cluster['engagement_level'].mean() if 'engagement_level' in cluster.columns else None
            st.markdown(f"""
            - 🧠 **Learning Style**: `{common_style}`
            - 📘 **Study Material Preference**: `{common_material}`
            - 📊 **Avg. Engagement**: `{avg_engagement:.2f}`""" if avg_engagement else "- Engagement data not available")

# --- Logic Based on User Input ---

if uploaded_file:
    df = load_data(uploaded_file)

    if menu == "🔎 Raw Data Preview":
        st.subheader("🔎 Raw Data Preview")
        st.dataframe(df)

    elif menu == "🧹 Outlier Removal":
        df_cleaned = remove_outliers(df)
        st.subheader("🧹 Cleaned Data (Outliers Removed)")
        st.dataframe(df_cleaned)

    elif menu == "⚙️ Preprocess Data":
        df_cleaned = remove_outliers(df)
        X, _ = preprocess(df_cleaned)
        st.subheader("⚙️ Preprocessed Data Info")
        st.success(f"Shape of Preprocessed Data: {X.shape}")

    elif menu == "📉 Elbow Method":
        df_cleaned = remove_outliers(df)
        X, _ = preprocess(df_cleaned)
        st.subheader("📉 Elbow Method for Optimal Clusters")
        find_optimal_k(X)

    elif menu == "🌀 Clustering":
        df_cleaned = remove_outliers(df)
        X, _ = preprocess(df_cleaned)
        k = st.slider("🔢 Select Number of Clusters", 2, 10, 4)
        labels, _ = perform_clustering(X, k)
        df_clustered = assign_cluster(df_cleaned, labels)
        st.subheader("🌀 Clustered Student Data")
        st.dataframe(df_clustered)

    elif menu == "📈 Cluster Analysis":
        df_cleaned = remove_outliers(df)
        X, _ = preprocess(df_cleaned)
        k = st.slider("🔢 Select Number of Clusters", 2, 10, 4)
        labels, _ = perform_clustering(X, k)
        df_clustered = assign_cluster(df_cleaned, labels)
        analyze_clusters(df_clustered)

else:
    st.warning("📎 Please upload a student CSV file to begin.")
